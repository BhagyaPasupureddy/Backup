import React from 'react';
import BookList from '../containers/booklist';
import BookDetails from '../containers/bookdetails';
import { CardGroup, Card } from 'reactstrap';

// var style={
// color:'blue'
// }
class App extends React.Component {

    render() {
        return (
            <div className="div1">
                <CardGroup>
                    <Card className="c1" >
                        <br />
                        <h2>BookTitle List</h2><hr />
                        <BookList />
                    </Card>
                    <Card>
                        <br />
                        <h2>Book Details</h2><hr />
                        <BookDetails />
                    </Card>
                </CardGroup>
            </div>
        );
    }
}

export default App;