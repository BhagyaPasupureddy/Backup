import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import registerServiceWorker from './registerServiceWorker';
import 'bootstrap/dist/css/bootstrap.css';
import {createStore} from 'redux';
//if u want to use only one variable or one func we use{}
import allReducers from './reducers';
import {Provider} from 'react-redux';
import App from './components/App';


const store=createStore(allReducers);
//if u don't want to change the value then use 'const'

//ReactDOM.render(<div>Hello</div>, document.getElementById('root'));
ReactDOM.render(
    <Provider store={store}>
    <App />
    </Provider>, document.getElementById('root'));
    
    //Provider makes store available to all components

registerServiceWorker();