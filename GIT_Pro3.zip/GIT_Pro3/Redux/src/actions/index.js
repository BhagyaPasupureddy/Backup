export const selectBook =(book) => {
   console.log("You clicked on book: ",book.booktitle);
   return {
    type: "BOOK_SELECTED",
    payload: book  //payload or data U can name it anyway 
   }
};