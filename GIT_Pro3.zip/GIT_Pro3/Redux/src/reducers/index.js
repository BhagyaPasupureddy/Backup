//combines all reducers as one obj
import {combineReducers} from 'redux';
import BooksReducer from './reducerbooks';
//u are importing reducerbooks and storing in a variable BooksReducer
//this obj allReducers will be thrown in "store"
import ActiveBookReducer from './reduceractivebook';
const allReducers = combineReducers({
    books: BooksReducer,  //books is nothing but the data in reducerbooks
    //if u have any other reducers combine them here 
    activeBook: ActiveBookReducer
});
export default allReducers;
