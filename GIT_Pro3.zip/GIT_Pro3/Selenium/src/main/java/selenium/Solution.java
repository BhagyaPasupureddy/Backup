package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Solution {

	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","D:\\Softwares\\selenium\\ChromeDriver 2.29\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://Google.com");
		driver.findElement(By.id("lst-ib")).sendKeys("hi");
		driver.findElement(By.xpath("//input[@value='Google Search']")).click();  //tagname-attributename-value
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		driver.quit();
	}
}
