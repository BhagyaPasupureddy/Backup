import React, { Component } from 'react';

import Header from './Header';
import MyCarousel from './Carousel';
import Quotes from './Quotes';
class App extends Component {
  render() {
    return (
      <div>
      
          <Header />
          <MyCarousel />
       </div>
    );
  }
}

export default App;