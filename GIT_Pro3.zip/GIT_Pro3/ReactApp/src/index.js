import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './modules/App';
import registerServiceWorker from './registerServiceWorker';
import 'bootstrap/dist/css/bootstrap.css';
import { Switch, Route, BrowserRouter } from 'react-router-dom';
import LogModal from './modules/LogModal';
import Quotes from './modules/Quotes';
import Header from './modules/Header';
import MyCarousel from './modules/Carousel';
import MyPlayer from './modules/Video';

ReactDOM.render((
  <div>
  <Header />
    <BrowserRouter>
    <Switch>
      <Route exact path='/' component={App}/>
      {/* both /roster and /roster/:number begin with /roster */}
      <Route exact path='/' component={App}/>      
      <Route path='/quotes' component={Quotes}/>
      <Route path='/video' component={MyPlayer}/>
    </Switch>
    </BrowserRouter>
    </div>
  ), document.getElementById('root'))

