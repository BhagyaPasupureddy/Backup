package com.mindtree.c2;

import java.util.Scanner;

public class Multidimensional {

	public static void main(String arg[])
	{

		Scanner s=new Scanner(System.in);
		
    }
}

