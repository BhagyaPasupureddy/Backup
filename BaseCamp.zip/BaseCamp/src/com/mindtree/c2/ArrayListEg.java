package com.mindtree.c2;

import java.util.ArrayList;

public class ArrayListEg {

	public static void main(String args[])
	{
		int n=5;
		ArrayList<Integer> al=new ArrayList<Integer>(n);
		  for(int i=0;i<n;i++)
		  {
			 al.add(i);
		  }
		  System.out.println(al);
		   
		  al.remove(3);
		  System.out.println(al);
	}
}