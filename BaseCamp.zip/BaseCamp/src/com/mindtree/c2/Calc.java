package com.mindtree.c2;

import java.util.Scanner;

public class Calc {

	public static void main(String arg[])
	{
	  int a1,b1;
	  System.out.println("Enter any two numbers:");
	  Scanner sc=new Scanner(System.in);
	  a1=sc.nextInt();
	  b1=sc.nextInt();
	  
	    add(a1,b1);
	  
	    System.out.println("Enter any two float values");
	     float a2=sc.nextFloat();
	     float b2=sc.nextFloat();
        sum(a2,b2);
        mul(a2,b2);
       System.out.println("Enter any character: ");
       String c1=sc.next();
       
	}
	static void add(int x,int y)
	{
		
		float sum=x+y;
	    System.out.println("Sum of int in float is: "+sum);
	    		
	}
	static void sum(float x,float y)
	{
		int a=(int)x;
		int b=(int)y;
		//System.out.println(a);
		//System.out.println(b);

		System.out.println("Sum of float in int is: "+(a+b));
		
	}
	static void mul(float a,float b)
	{
		//System.out.println((int)b);
		float result=a*(int)b;
		System.out.println("Result is: "+result);
	}
	
	
}
