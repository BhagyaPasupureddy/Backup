package com.mindtree.c1;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		int arr[]={44,33,23,11,6,9};
		System.out.println("Enter any element");
		int x=sc.nextInt();
		int r=search(arr,x);
		  if(r==-1)
		    System.out.println("Element not found");
		  else
			  System.out.println("Element found at index "+r);
		
	}

	private static int search(int[] arr, int x) {
		// TODO Auto-generated method stub
	
		int n=arr.length;
		 for(int i=0;i<n;i++)
		 {
			 if(arr[i]==x)
			 {
                 return i;				 
			 }
			 
		 }
		 return -1;
	}
}
