function makejson(form)
{
    var myJson,text,obj;
    console.log("Hello");
    var json={
        
      "book1": {
        "book_title":"India After Gandhi",
        "author_name":"Ramachandra Guha"
       
    },
    
     "book2":{  
     "book_title":"The Power Of Your Subconscious Mind",
        "author_name":"Dr.Joseph Murthy"
       
    },
    
       "book3":{  
          "book_title": "Beartown: A Novel",
           "author_name":" Fredrik Backman"
          },
        
    };
    console.log(json);
    
   // var json = { "book_title": form.book_title.value,  "author_name": form.author_name.value};


    myJson=JSON.stringify(json);
    console.log(myjson);    
    document.getElementById("print").innerHTML = myjson;
    
    return json;
    
}