import React from 'react';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

class FormApp extends React.Component {
  render() {
    return (
      <Form>
        <FormGroup>
          <Label for="exampleEmail">Email</Label>
          <Input type="email" name="email" id="exampleEmail" placeholder="Enter your Email" />
        </FormGroup>
        <FormGroup>
          <Label for="examplePassword">Password</Label>
          <Input type="password" name="password" id="examplePassword" placeholder="Enter your Password" />
        </FormGroup>
        </Form>
      );
    }
  }
  export default FormApp;