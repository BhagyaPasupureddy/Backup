import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route } from 'react-router'
import { BrowserRouter } from 'react-router-dom';
import { Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLink } from 'reactstrap';
import App from './App';
import LogModal from './LogModal';
import Quotes from './Quotes';
import MyPlayer from './Video';
class Header extends React.Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
    return (

      <div>
        <Navbar fixed="top" className="myNav" toggleable color="faded">
          <NavbarToggler onClick={this.toggle} />
          <NavbarBrand href="/">MyWorld</NavbarBrand>
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
              <NavItem>
                <NavLink href="/">Home</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/Quotes/">Quotes</NavLink>
              </NavItem>
              <NavItem>
              <NavLink href="/Video/">Marathon Of Life</NavLink>
            </NavItem>
              <NavItem>
                <LogModal />
              </NavItem>

            </Nav>
          </Collapse>
        </Navbar>

      </div>
    );
  }
}
export default Header;