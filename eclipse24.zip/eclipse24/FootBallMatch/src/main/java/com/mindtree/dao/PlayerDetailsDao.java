package com.mindtree.dao;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.daoimpl.PlayersImpl;
import com.mindtree.entity.Player;
import com.mindtree.manager.PlayerAuctionSystemManager;

/**
 * Servlet implementation class PlayerDetailsDao
 */
@WebServlet("/PlayerDetailsDao")
public class PlayerDetailsDao extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlayerDetailsDao() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//doGet(request, response);
		String Player_Name = request.getParameter("Player_Name");
		String Category = request.getParameter("Category");
		String HighestScore = request.getParameter("HighestScore");
		String BestFigure = request.getParameter("BestFigure");
		String Team_Name = request.getParameter("Team_Name");
		
		DbUtil db = new DbUtil();
		Player p = new Player();
		p.setPlayer_Name(Player_Name);
		p.setCategory(Category);
		p.setHighestScore(Integer.parseInt(HighestScore));
		p.setBestFigure(BestFigure);
		p.setTeamName(Team_Name);
		String msg=PlayerAuctionSystemManager.TestException(p);
		System.out.println("Msg = "+msg);
		RequestDispatcher rd;
			rd=request.getRequestDispatcher("addplayers");
			request.setAttribute("msg", msg);
			rd.forward(request, response);
	}

}
