package com.mindtree.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;

import com.mindtree.dao.DbUtil;
import com.mindtree.entity.Player;

public class PlayersImpl extends HttpServlet{

	public static String AddPlayer(String Player_Name, String category, String HighestScore, String BestFigure,
			String Team_Name, DbUtil db) {
		int Team_Id=0,Player_No=0;
		Statement st;
  		try{
  			st=db.getCon().createStatement();	
  			String s="select Team_Id from team where team.Team_Name='"+Team_Name+"'";
  			ResultSet rs=st.executeQuery(s);
  			while(rs.next()) {
        	   Team_Id=rs.getInt("Team_Id");
        	  }
  			st.executeUpdate("insert into player (Player_Name,Category,HighestScore,BestFigure)values('"+Player_Name+"','"+category+"','"+HighestScore+"','"+BestFigure+"')" );
  			String s1="select Player_No from player order by Player_No desc limit 1";
  			ResultSet rs1=st.executeQuery(s1);
  			while(rs1.next()){
  				Player_No=rs1.getInt("Player_No"); 
  				}
  			st.executeUpdate("insert into team_player values("+Player_No+","+Team_Id+")");

  		}
  		catch(SQLException e){
  			e.printStackTrace();
  		}
		return "player Added Successfully";
	}

	

}
