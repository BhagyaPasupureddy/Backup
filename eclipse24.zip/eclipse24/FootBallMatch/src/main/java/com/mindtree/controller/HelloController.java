package com.mindtree.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.entity.Player;
import com.mindtree.manager.PlayerAuctionSystemManager;

@Controller
public class HelloController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String printWelcome(ModelMap model) {

		model.addAttribute("message", "Spring 3 MVC Hello World");
		return "hello";

	}

	/*@RequestMapping(value = "/hello/{name:.+}", method = RequestMethod.GET)
	public ModelAndView hello(@PathVariable("name") String name) {

		ModelAndView model = new ModelAndView();
		model.setViewName("hello");
		model.addObject("msg", name);

		return model;
		}
*/

	@RequestMapping(value = "hello", method = RequestMethod.GET)
	public String Home(ModelMap model11) {

		model11.addAttribute("message", "Spring 3 MVC Hello World");
		return "hello";
	
	}
	
	@RequestMapping(value = "addplayer", method = RequestMethod.GET)
	public String addPlayer(ModelMap model1) {

		model1.addAttribute("message", "Spring 3 MVC Hello World");
		return "addPlayer";
	
	}
	@RequestMapping(value = "addplayers", method = RequestMethod.GET)
	public String addPlayers(ModelMap model1) {

		model1.addAttribute("message", "Spring 3 MVC Hello World");
		return "addPlayers";
	
	}
	
	@RequestMapping(value = "displayplayer", method = RequestMethod.GET)
	public String displayPlayer(ModelMap model2) {

		model2.addAttribute("message", "Spring 3 MVC Hello World");
		return "displayPlayer";
	
	}
	@RequestMapping(value = "displayplayers", method = RequestMethod.GET)
	public String displayPlayers(ModelMap model2) {

		model2.addAttribute("message", "Spring 3 MVC Hello World");
		return "displayPlayers";
	
	}

	@RequestMapping(value = "/PlayerDetailsDao", method = RequestMethod.POST)
	public ModelAndView PlayerDetailsDao(
			@RequestParam(value="playername") String playername,
			@RequestParam(value="category") String category,
			@RequestParam(value="highestscore") String highestScore, 
			@RequestParam(value="bestFigure") String bestFigure,
			@RequestParam(value="teamName") String teamName) {

		/*System.out.println("TESTING");
		System.out.println(fName);
		String n = "";
		
		n = fName + "-" + mName + "-" + lName;
		model.addObject("msg", n);*/
		
		ModelAndView model = new ModelAndView();
		Player t = new Player();
		t.setPlayer_Name(playername);
		t.setCategory(category);
		t.setHighestScore(Integer.parseInt(highestScore));
		t.setBestFigure(bestFigure);
		t.setTeamName(teamName);
		String msg=PlayerAuctionSystemManager.TestException(t);
		model.setViewName("Success");
		model.addObject("msg", msg);
		
		return model;

	}
	

}