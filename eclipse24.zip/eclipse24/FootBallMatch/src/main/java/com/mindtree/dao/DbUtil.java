package com.mindtree.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DbUtil {
	private Statement st=null;
	private Connection con;

	public DbUtil() {
		// TODO Auto-generated constructor stub
		try{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/players_db","root","Welcome123");
		setSt(con.createStatement());
		}
		catch(ClassNotFoundException e)
		{
			
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	
	}
	public void dbClose()
	{
		try{
		con.close();
	}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	public Statement getSt() {
		return st;
	}
	public void setSt(Statement st) {
		this.st = st;
	}
	public Connection getCon() {
		return con;
	}

}
