package com.mindtree.entity;

public class Team {

	int Team_Id;
	String Team_Name;
	public int getTeam_Id() {
		return Team_Id;
	}
	public void setTeam_Id(int team_Id) {
		Team_Id = team_Id;
	}
	public String getTeam_Name() {
		return Team_Name;
	}
	public void setTeam_Name(String team_Name) {
		Team_Name = team_Name;
	}
	
}
