package com.mindtree.daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;

import com.mindtree.dao.DbUtil;
import com.mindtree.entity.Player;

public class TeamDaoImpl extends HttpServlet{

	
	public static boolean GetTeams(String team_Name, String player_Name, String category) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/player_db","root","Welcome123");
		Statement st=con.createStatement();
		System.out.println("==="+team_Name+","+player_Name+","+category);
		ResultSet rs=st.executeQuery("select * from players_db.team t,players_db.player p,players_db.team_player tp where t.Team_Id=tp.Team_Id and p.Player_No = tp.Player_No and t.Team_Name='"+team_Name+"' and p.player_Name='"+player_Name+"' and p.Category='"+category+"' ");
		while(rs.next()){
			
			return true;
		}
		con.close();
		return false;
	}

	

}
