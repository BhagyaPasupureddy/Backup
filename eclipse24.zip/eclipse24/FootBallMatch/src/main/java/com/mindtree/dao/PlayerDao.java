package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mindtree.entity.Player;

public class PlayerDao {

	public static String AddPlayer(Player p) throws SQLException {
		int Team_Id=0,Player_No=0;
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/players_db","root","Welcome123");
		Statement st;
  		try{
  			st=con.createStatement();
  			st.executeUpdate("insert into player (Player_Name,Category,HighestScore,BestFigure) values ('"+p.getPlayer_Name()+"','"+p.getCategory()+"','"+p.getHighestScore()+"','"+p.getBestFigure()+"')" );
  			
  			String s="select Team_Id from team where Team_Name='"+p.getTeamName()+"'";
  			ResultSet rs=st.executeQuery(s);
  			while(rs.next()) {
        	   Team_Id=rs.getInt("Team_Id");
        	  }
  			String s1="select Player_No from player order by Player_No desc limit 1";
  			ResultSet rs1=st.executeQuery(s1);
  			while(rs1.next()){
  				Player_No=rs1.getInt("Player_No"); 
  				}
  			st.executeUpdate("insert into team_player values("+Player_No+","+Team_Id+")");
           
  		}
  		catch(SQLException e){
  			e.printStackTrace();
  		}
		return "Player added successfully";
		}

}
