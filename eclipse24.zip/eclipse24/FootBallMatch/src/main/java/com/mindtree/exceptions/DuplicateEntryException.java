package com.mindtree.exceptions;

public class DuplicateEntryException extends Exception{


	public DuplicateEntryException(String message) {
		super( message);
		// TODO Auto-generated constructor stub
	}
}
