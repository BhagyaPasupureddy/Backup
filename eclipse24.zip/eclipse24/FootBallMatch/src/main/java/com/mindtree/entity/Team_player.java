package com.mindtree.entity;

public class Team_player {
	int Player_No;
	int Team_Id;
	public int getPlayer_No() {
		return Player_No;
	}
	public void setPlayer_No(int player_No) {
		Player_No = player_No;
	}
	public int getTeam_Id() {
		return Team_Id;
	}
	public void setTeam_Id(int team_Id) {
		Team_Id = team_Id;
	}
}
