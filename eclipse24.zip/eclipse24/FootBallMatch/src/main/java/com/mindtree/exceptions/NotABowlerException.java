package com.mindtree.exceptions;

public class NotABowlerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotABowlerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
