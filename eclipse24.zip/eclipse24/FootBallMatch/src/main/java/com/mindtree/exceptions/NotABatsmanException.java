package com.mindtree.exceptions;

public class NotABatsmanException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotABatsmanException(String msg)
	{
		super(msg);
	}
}
