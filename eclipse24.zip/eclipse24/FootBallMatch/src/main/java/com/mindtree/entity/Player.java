package com.mindtree.entity;

public class Player {

	int Player_No;
	String Player_Name;
	String Category;
	int HighestScore;
	String BestFigure;
	public int getPlayer_No() {
		return Player_No;
	}
	public void setPlayer_No(int player_No) {
		Player_No = player_No;
	}
	public String getPlayer_Name() {
		return Player_Name;
	}
	public void setPlayer_Name(String player_Name) {
		Player_Name = player_Name;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getHighestScore() {
		return HighestScore;
	}
	public void setHighestScore(int highestScore) {
		HighestScore = highestScore;
	}
	public String getBestFigure() {
		return BestFigure;
	}
	public void setBestFigure(String bestFigure) {
		BestFigure = bestFigure;
	}
	public Player(String player_Name, String category, int highestScore,
			String bestFigure) {
		super();
		Player_Name = player_Name;
		Category = category;
		HighestScore = highestScore;
		BestFigure = bestFigure;
	}
	
	String teamName;
	public String getTeamName() {
		return teamName;
	}
	
	
	public Player(String player_Name, String category, int highestScore,
			String bestFigure, String teamName) {
		super();
		Player_Name = player_Name;
		Category = category;
		HighestScore = highestScore;
		BestFigure = bestFigure;
		this.teamName = teamName;
	}
	
	public Player() {
		// TODO Auto-generated constructor stub
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	
	
}
