package com.mindtree.manager;

import java.sql.SQLException;
import com.mindtree.dao.PlayerDao;
import com.mindtree.dao.TeamDao;
import com.mindtree.daoimpl.TeamDaoImpl;
import com.mindtree.entity.Player;
import com.mindtree.exceptions.DuplicateEntryException;
import com.mindtree.exceptions.InvalidCategoryException;
import com.mindtree.exceptions.InvalidTeamNameException;
import com.mindtree.exceptions.NotABatsmanException;
import com.mindtree.exceptions.NotABowlerException;

public class PlayerAuctionSystemManager {

	public static String TestException(Player p) 
	{
		
		String result=new String();
		try
		{
		 String Category=p.getCategory();
		 if(!(Category.equals("Batsman") ||Category.equals("Bowler") ||Category.equals("All-rounder")||Category.equals("Allrounder")||Category.equals("all-rounder")||Category.equals("allrounder")||Category.equals("All-Rounder")||Category.equals("batsman")||Category.equals("bowler")))
		  {
			  throw new InvalidCategoryException("Invalid category name please check your input");
		  }
		 String Team_Name=p.getTeamName();
		 if(!(TeamDao.GetTeamName(Team_Name))){
			 throw new InvalidTeamNameException("Invalid Team Name,Please check your input");
		 }
		 int HighestScore=p.getHighestScore();
		 if((Category.equals("Batsman")) && ((HighestScore<50) || (HighestScore>400))){
			 throw new NotABatsmanException("Invalid Batsman , Please Check Your Input");
		 }
		String BestFigure=p.getBestFigure();
		  if((Category.equals("Bowler") && (BestFigure==null || HighestScore<0))){
			  throw new NotABowlerException("Invalid Bowler,Please Check Your Input");
		  }
		  String Player_Name=p.getPlayer_Name();
		  if(TeamDaoImpl.GetTeams(Team_Name,Player_Name,Category)){
			  throw new DuplicateEntryException("Duplicate Entry");
		  }
		  else
			  
		  {
				 result=PlayerDao.AddPlayer(p);

		  }
		}
	
	catch(ClassNotFoundException e){
		e.printStackTrace();
	}catch(SQLException e){
		e.printStackTrace();
	}catch(InvalidCategoryException e){
		result=e.getMessage();
		System.out.println(result);
	}catch(InvalidTeamNameException e){
		result=e.getMessage();
		System.out.println(result);
	}catch(NotABatsmanException e){
		result=e.getMessage();
		System.out.println(result);
	}catch(NotABowlerException e){
		result=e.getMessage();
		System.out.println(result);
	}catch(DuplicateEntryException e){
		result=e.getMessage();
		System.out.println(result);
	}
		
		return result;
		
	}
	
	
	
	
}

