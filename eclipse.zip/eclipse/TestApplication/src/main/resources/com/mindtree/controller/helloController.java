package com.mindtree.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class helloController {

	@RequestMapping("/hi")
	public ModelAndView getAdmissionFormere() {

		ModelAndView model1 = new ModelAndView("hello");
		model1.addObject("welcomeMessage","Hello World");
		return model1;
	}

	
}
