import React from 'react';


class MyPlayer extends React.Component {
    render() {

        return (
            <div>
                <iframe title="Marathon Of Life" width="100%" height="755" className="player" type="text/html" max-width="100%" max-height="100%"
                    src="https://www.youtube.com/embed/S_dbMoNx_Hg"
                    frameborder="0" />
            </div>

        );
    }
}


export default MyPlayer;