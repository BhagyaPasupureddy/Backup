import React from 'react';
import { Jumbotron, Container } from 'reactstrap';
class Quotes extends React.Component{

    render(){
        return(
            <div>
              <Jumbotron fluid padding='10px'>
              <Container fluid>
                <h1 className="text-primary" align="center">Dreams</h1>
                <br/>
                <p className="lead" color="text-info" align="center">Everyone's dreams won't be same.<br/>
                Neither compare nor compete with others dreams <br/>
                You have your own life <br/>
                Dream for it <br />
                Make it as beautiful and as cheerful as you can.<br/>
                Live for your dreams Make them come true.
                </p>
                </Container>
                </Jumbotron>
                <Jumbotron fluid padding='10px'>                
                <Container fluid>           
                <h1 className="text-primary" align="center">Design</h1>
                <br/>
                <p className="lead" color="text-info" align="center" background-color="black">Design Your Life Based on Your Thoughts and Actions.<br/> Not based on "Their" Judgements
                </p>
              </Container>
            </Jumbotron>
            </div>
        );
    }
}
export default Quotes;
