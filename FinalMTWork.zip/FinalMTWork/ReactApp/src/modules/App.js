import React, { Component } from 'react';
import Header from './Header';
import MyCarousel from './Carousel';
import Link from '../Link';
class App extends Component {
  render() {
    return (
      <div>
      
          <Header />
          <Link />
          <MyCarousel />
       </div>
    );
  }
}

export default App;