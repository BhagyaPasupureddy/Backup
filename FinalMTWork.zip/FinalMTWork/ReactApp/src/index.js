import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './modules/App';
import 'bootstrap/dist/css/bootstrap.css';
import { Switch, Route, BrowserRouter } from 'react-router-dom';
import Quotes from './modules/Quotes';
import Header from './modules/Header';
import MyPlayer from './modules/Video';

ReactDOM.render((
  <div>
  <Header />
    <BrowserRouter>
    <Switch>
      <Route exact path='/' component={App}/>
      {/* both /roster and /roster/:number begin with /roster */}
      <Route exact path='/' component={App}/>      
      <Route path='/quotes' component={Quotes}/>
      <Route path='/video' component={MyPlayer}/>
    </Switch>
    </BrowserRouter>
    </div>
  ), document.getElementById('root'))

