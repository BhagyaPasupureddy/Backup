//Reducer is a piece of data u want to store in your Store 
// If u want another list u can create another reducer class like reducermusic or reducermovie
//In store we can pass ony one obj so, combine all the reducer classes into one big obj "index"

export default function(){
    return[
        {
            id: 1,
            booktitle: "Harry Potter and the Sorcerer's Stone",
            authorname:"J.K. Rowling",
            genre: "Fiction",
            description: "Harry Potter is raised by reluctant parents, Aunt Petunia and Uncle Vernon, an odious couple who would be right at home in a Roald Dahl novel. Things go from awful to hideous for Harry until, with the approach of his eleventh birthday, mysterious letters begin arriving addressed to him! His aunt and uncle manage to intercept these until a giant named Hagrid delivers one in person, and to his astonishment, Harry learns that he is a wizard and has been accepted (without even applying) as a student at Hogworts School of Witchcraft and Wizardry. There's even more startling news: it turns out that his parents were killed by an evil wizard so powerful that everyone is afraid to so much as utter his name, Voldemort. Somehow, though, Harry survived Voldemort's attempt to kill him, too, though it has left him with a lightning-shaped scar on his forehead and enormous celebrity in the world of magic, because Voldemort vanished following his failure. But is he gone for good? What is hidden on the third floor of Hogworts Castle? And who is the Man with Two Faces? Rowling's first novel, which has won numerous prizes in England, is a brilliantly imagined and beautifully written fantasy that incorporates elements of traditional British school stories without once violating the magical underpinnings of the plot. In fact, Rowling's wonderful ability to put a fantastic spin on sports, student rivalry, and eccentric faculty contributes to the humor, charm, and, well, delight of her utterly captivating story.",
            thumbnail:"https://i.ytimg.com/vi/RzCjI3Jy7E8/movieposter.jpg"
        },
        {
            id: 2,
            booktitle: "The Lord of the Rings",
            authorname:" J.R.R. Tolkien",
            genre: "Literature & Fiction",
            description: "Three Rings for the Elven-kings under the sky, Seven for the Dwarf-lords in their halls of stone Nine for Mortal Men doomed to die, One for the Dark Lord on his dark throne In the Land of Mordor where the Shadows lie. One Ring to rule them all, One Ring to find them, One Ring to find them, One Ring to bring them all and in the darkness bind them In the Land of Mordor where the Shadows lie.' In ancient times the Rings of Power were crafted by the Eleven-smiths, and Sauron, the Dark Lord, forged the One Ring, filling it with his own power so that he could rule all others. But the One Ring was taken from him, and though he sought it throughout Middle-earth still it remained lost to him. After many ages it fell, by chance, into the hands of the hobbit, Bilbo Baggins. From his fastness in the Dark Tower of Mordor, Sauron's power spread far and wide. He gathered all the Great Rings to him, but ever he searched for the One Ring that would complete his dominion. On his eleventy-first birthday, Bilbo disappeared, bequeathing to his young cousin, Frodo, the Ruling Ring, and a perilous quest: to journey across Middle-earth, deep into the shadow of the Dark Lord and destroy the Ring by casting it into the Cracks of Doom. The lord of the rings tells of the great quest undertaken by Frodo and the Fellowship of the Ring: Gandalf the wizard, Merry, pippin and Sam, Gimli the Dwarf, Legolas the Elf, Boromir of Gondor, and a tall, mysterious stranger called Strider.",
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51d4G0sFMzL.jpg"
        },
        {
            id: 3,
            booktitle: "The Hobbit",
            authorname:"J.R.R. Tolkien",
            genre: "Science Fiction & Fantasy",
            description: "Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious life, rarely travelling further than the pantry of his hobbit-hole in Bag End. But his contentment is disturbed when the wizard, Gandalf and a company of thirteen dwarves arrive on his doorstep one day to whisk him away on an unexpected journey ‘there and back again'. They have a plot to raid the treasure hoard of Smaug the Magnificent, a large and very dangerous dragon. The prelude to The Lord of the Rings, The Hobbit has sold many millions of copies since its publication in 1937, establishing itself as one of the most beloved and influential books of the twentieth century",
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51R5PheWaAL._SX326_BO1,204,203,200_.jpg"
        },

        {
            id: 4,
            booktitle: "When Breath Becomes Air",
            authorname:"Paul Kalanithi",
            genre: "Non Fiction",
            description: "'Finishing this book and then forgetting about it is simply not an option...Unmissable' New York Times.At the age of thirty-six, on the verge of completing a decade’s training as a neurosurgeon, Paul Kalanithi was diagnosed with inoperable lung cancer. One day he was a doctor treating the dying, the next he was a patient struggling to live.When Breath Becomes Air chronicles Kalanithi’s transformation from a medical student asking what makes a virtuous and meaningful life into a neurosurgeon working in the core of human identity – the brain – and finally into a patient and a new father. What makes life worth living in the face of death? What do you do when when life is catastrophically interrupted? What does it mean to have a child as your own life fades away?Paul Kalanithi died while working on this profoundly moving book, yet his words live on as a guide to us all. When Breath Becomes Air is a life-affirming reflection on facing our mortality and on the relationship between doctor and patient, from a gifted writer who became both.",
            thumbnail:"https://jamesclear.com/wp-content/uploads/2016/10/WHEN-BREATH-BECOMES-AIR-by-PAUL-KALANITHI-474x700.jpg?x32321"
        },
        
        {
            id: 5,
            booktitle: "Sapiens: A Brief History of Humankind",
            authorname:"Yuval Noah Harari",
            genre: "Non Fiction",
            description: "Human history has been shaped by three major revolutions: the Cognitive Revolution (70,000 years ago), the Agricultural Revolution (10,000 years ago), and the Scientific Revolution (500 years ago). These revolutions have empowered humans to do something no other form of life has done, which is to create and connect around ideas that do not physically exist (think religion, capitalism, and politics).FIRE gave us power....FARMING made us hungry for more....MONEY gave us purpose....SCIENCE made us deadly....This is the thrilling account of our extraordinary history – from insignificant apes to rulers of the world. ",
            thumbnail:"https://jamesclear.com/wp-content/uploads/2016/06/sapiens-by-yuval-noah-harari-469x700.jpg?x32321"
        },
        
        {
            id: 6,
            booktitle: "The Power of your Subconscious Mind",
            authorname:"Joseph Murphy",
            genre: "Non Fiction",
            description: "Did you know that your mind has a 'mind' of its own? Yes! Without even realizing, our mind is often governed by another entity which is called the sub-conscious mind. This book can bring to your notice the innate power that the sub-conscious holds. We have some traits which seem like habits, but in reality these are those traits which are directly controlled by the sub-conscious mind, vis-à-vis your habits or your routine can be changed if you can control and direct your sub-conscious mind positively. To be able to control this 'mind power' and use it to improve the quality of your life is no walk in the park. This is where this book acts as a guide and allows you to decipher the depths of the sub-conscious.In this book, 'The power of your subconscious mind', the author fuses his spiritual wisdom and scientific research to bring to light how the sub-conscious mind can be a major influence on our daily lives. Once you understand your subconscious mind, you can also control or get rid of the various phobias that you may have in turn opening a brand new world of positive energy.",
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51QTTApN-XL._SX324_BO1,204,203,200_.jpg"
        },
        {
            id: 7,
            booktitle: "The Immortals of Meluha (Shiva Trilogy) ",
            authorname:"Amish",
            genre: "Mythology",
            description: "An intense story 'The Immortals of Meluha' draws heavily from stories and legends of Hindu mythology that have been passed on from generation to generation.First book of the trilogy, the Immortals tale unfolds in Meluha, a land that is ruled by the Suryavanshi tribe that firmly believes in the prophecy of 'Neelkanth' Shiva being their saviour. The Suryavanshi’s (Sun worshipers) are of the firm belief that it would be Shiva who would save them from the wrath of Chandravanshi’s (Moon worshipers).Blending mythology and philosophy drawn from Hindu traditions, the gripping narrative moves with speed to have Shiva step up to take it upon himself about banishing evil from society.As the tribal leader of Meluha, somewhere in Tibet, Shiva decides to help the Suryavanshi's in their fight against the Chandravanshi, who have allied with the Nagas, a cursed tribe.As the drama unfolds, Shiva, the tribal leader from Tibet, gets caught up between the two warring groups, where a realization dawns upon him of how his choice was affecting the war outcome as well as of aspirations of rising above the conflict and its actors begins to dominate the narrative.The author has creatively woven the legend of Lord Shiva; His marriage to King Daksha's daughter Sati is this first part of the trilogy.'Secret of Nagas' and 'Oath of the Vayuputras' the second and third part of the same narrative take the story forward as the first part ends with Shiva charging to save Sati from being taken captive by the Naga's.Spread out in 415 pages, 'The Immortals of Meluha' was first published in 2011. After a slow start, the book soon turned a bestseller and more than two million copies have been sold. Till date it has been translated in fourteen languages.",
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51m0wvVXZ1L._SX319_BO1,204,203,200_.jpg"
        },
        {
            id: 8,
            booktitle: "The Secret Of The Nagas (Shiva Trilogy-2)",
            authorname:"Amish",
            genre: "Mythology",
            description: "About The Saga- The Shiva Trilogy, written by Amish Tripathi, has become a nation-wide bestseller in a short time. This is due to the refreshing new plot that it explores and the unique writing style of the author. The Secret of The Nagas is the second novel in the saga. Amish has penned down the contents of this book in such a way that it manages to shine as a stand-alone book in itself.The Plot and The Characterisations-In this book, Amish describes how Shiva sets forth on a quest to destroy the Naga clan in order to avenge the death of his brother; since the common belief he has been presented with is that the Nagas are the root of all evil. The author takes us through a virtual tour of India as Shiva travels different lands and gathers a vast number of generic and non-generic experiences, all in the quest of saving a plagued kingdom. As he travels, he garners more friends and family and leaves a mark. Slowly, events start unfolding in such a manner that whatever beliefs the readers and Shiva too held in the previous book are tarnished. Revelations occur as the evil-doers have been showcased in a new light and the grey shades of the positive protagonists in the earlier book are exposed. The book is filled with nuanced wisdom and Shiva leaves the readers with the message that good and evil are two sides of the same coin; which is why we shouldn't judge people. As suspense builds, the climax ends with Shiva finally entering the Naga territory making for a nail-biting finish.",
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51djIve%2B9UL._SX329_BO1,204,203,200_.jpg"
        },
        {
            id: 9,
            booktitle: "The Oath of the Vayuputras (Shiva Trilogy)",
            authorname:"Amish Tripati",
            genre: "Mythology",
            description: "The final book of the famous Shiva Trilogy, the Oath of Vayuputras was published on February 27, 2013 and completes the story about a nomad named Shiva and how he saved the inhabitants of the imaginary land Meluha.This book also reveals Shiva’s questions about his own fate, the choices he made in past and about karma. He is also seen reaching Panchavati, the Naga capital and gathering forces to fight a holy war against his archrival, a man whose name resonates with rage and fierceness.With this commences a series of brutal wars and battles. The battles are synonymous to torture and brutality, it may perhaps end by engulfing numerous lives; but Shiva has to prevail amidst all odds. It is in this desperation that he reaches out for help to the Vayuputras. Will truth prevail and brutality be dead? Will Shiva be able to be victorious? Unearth these answers in this concluding part of the Shiva Trilogy—The Oath Of Vayuputras.",
            
            thumbnail:"https://images-na.ssl-images-amazon.com/images/I/51xPaakXT3L._SX349_BO1,204,203,200_.jpg"
        },
        {
            id: 10,
            booktitle: "Raavan: Orphan of Aryavarta ",
            authorname:"Amish Tripati",
            genre: "Mythology",
            description: "The mighty Lord of Lanka, Raavan, sets out to avenge the insult of his sister, Shurpanakha at the hands of the younger prince of Ayodhya, Lakshman. Aware that the Ayodhya royal trio are in exile he flies to Dandakaranya in the Lankan military aircraft, the Pushpak Vimaan. His mission? To capture the Vishnu. For far will Raavan go to seek revenge?",
            thumbnail:"https://images-eu.ssl-images-amazon.com/images/I/5113Nm-alLL.jpg"
        },
    ]

}