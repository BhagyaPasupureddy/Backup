import React, { Component } from 'react';
import {connect} from 'react-redux';
import { Card, CardImg, CardGroup ,CardBody, CardTitle, CardSubtitle, CardText} from 'reactstrap';
class BookDetails extends Component{
    render(){
        if(!this.props.book){
            return(<h2>Select a Book.... </h2>);
        }
        return(
            <div>
            <CardGroup>
            <Card>
            <CardImg src={this.props.book.thumbnail} alt={this.props.booktitle}/>
            </Card>
            <Card>
            <CardBody>
            <CardTitle>{this.props.book.booktitle}</CardTitle>
            <CardSubtitle>-{this.props.book.authorname}
            </CardSubtitle>
            <CardText>
            <br/>
            <h5>Genre: {this.props.book.genre}</h5><hr />
            <h6>About the Book:</h6>
            {this.props.book.description}</CardText>
            </CardBody>
            </Card>
            </CardGroup>     
            </div>
        );
    }
}
function mapStateToProps(state){
    return{
      book: state.activeBook
    };
}
export default connect(mapStateToProps)(BookDetails);