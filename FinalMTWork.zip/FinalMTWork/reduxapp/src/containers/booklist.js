import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {selectBook} from '../actions/index';

class BookList extends Component {

      createListItems(){
            return this.props.books.map((book) => {return (
                <li key={book.id} 
                onClick={() => this.props.selectBook(book)}> {book.booktitle}
                </li>
            );
});
      }
    render() {
        return (
            <ul>
              {this.createListItems()}
            </ul>
        );
    }
}
//Takes your App's store and passes into component as a property
//Takes a state of your app and passes as a prop to your component
  function mapStateToProps(state){
      return{
        books: state.books
      };
  }

  function matchDispatchToProps(dispatch){
      return bindActionCreators({selectBook:selectBook},dispatch)
  }
export default connect(mapStateToProps,matchDispatchToProps)(BookList);
