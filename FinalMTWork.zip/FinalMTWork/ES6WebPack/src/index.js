import './styles.scss';
var msg = x=> { 
    console.log(x) 
 } 
 msg(10)
 function compareFunction(a, b) 
 {
     return a - b;
 }
 function updateTable() 
 {
     let student = document.getElementById("sname").value;
     let marks = document.getElementById("marks").value;
     console.log(student);
     console.log(marks);
     document.getElementById("s1").innerHTML = student;
     document.getElementById("td5").innerHTML = marks;
     let arr = [], myarr = [];
     let i, j, ind;
    // console.log("Hi");
     for (i = 1, j = 1; i < 6; i++ , j + 2) 
     {
         arr[i] = mytable.rows[i].cells[j].innerHTML;
         myarr[i] = mytable.rows[i].cells[j].innerHTML;
         console.log(arr[i]);
     }
     console.log(myarr);
     arr.sort(function (a, b) { return a - b })
     console.log(arr);
     let maxindex = myarr.lastIndexOf(arr[arr.length - 2]);
     console.log(maxindex);
     mytable.rows[maxindex].style.backgroundColor = "yellow";
     document.getElementById("myform").reset();
     return false;
 }