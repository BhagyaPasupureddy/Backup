/**
 * 
 */
/**
 * @author M1041807
 *
 */
package com.mindtree.model;

public class Shop {

	String name;
	String staffName[];

	//getter and setter methods

}