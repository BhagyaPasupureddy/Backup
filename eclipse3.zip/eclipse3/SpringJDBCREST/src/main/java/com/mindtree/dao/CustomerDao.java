package com.mindtree.dao;

import com.mindtree.model.Customer;
public interface CustomerDao {

	public void insert(Customer customer);
	public Customer findByCustomerId(int custId);
	
}
