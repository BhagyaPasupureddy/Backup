package com.mindtree.spring.config;

public class AppConfig {
	
	

}
