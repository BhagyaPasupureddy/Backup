package com.mindtree.entity;

public class Hello {
String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

}
