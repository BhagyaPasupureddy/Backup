package com.mindtree.entity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSevice {
	@SuppressWarnings("resource")
	public static void main(String[] args){
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Hello hello= (Hello) context.getBean("hello");
		hello.setName("Baaghi");
		System.out.println("Hi " + hello.getName());
	}

}
