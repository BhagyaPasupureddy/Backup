import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import AppBar from 'material-ui/AppBar';
import Toolbar from 'material-ui/Toolbar';
import Typography from 'material-ui/Typography';
import Button from 'material-ui/Button';
import './nav-bar.component.css';
//import { EduModal,EduModalRaised } from '../modal/modal.component';
import TemporaryDrawer from '../drawers-search/drawers-search';
//import search from './search.jpg'; 
import SignUp from '../../modules/signup/signup.js';
import LogIn from '../../modules/userEntry/login/login.component.js';

const styles = {
  root: {
    marginTop: 0,
    width: '100%',
    
  },
  flex: {
    flex: 1,
  },
};

function ButtonAppBar(props) {
  const classes = props.classes;
  return (
    <div className={classes.root} >
          <AppBar position="fixed" className="nav1" >
          <Toolbar>
            <div className={classes.flex} >
            <Typography type='title' className="text-clr big" >

             EduCentral    {' '}     
            <Button  className="text-clr" >Home</Button>
            <Button  className="text-clr" >About Us</Button>
            <Button  className="text-clr" >Contact Us</Button>
            <Button  className="text-clr"><TemporaryDrawer className="text-clr">Click to Search</TemporaryDrawer></Button>
            
              </Typography>  </div>

            <LogIn />{' '}
            <SignUp />

          </Toolbar>
        </AppBar>  
    </div>
  );
}

ButtonAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(ButtonAppBar);