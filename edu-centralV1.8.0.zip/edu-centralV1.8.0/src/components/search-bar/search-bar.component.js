import React from 'react';
import Button from 'material-ui/Button';


  const  EduSearchBar = React.createClass({

        render() {
          return (
                <Button
                    style={{width:'500px',background:'black'}} 
                >{this.props.children}</Button>
              
          );
        }
      });

  export {EduSearchBar};