
  import React from 'react';
  import Button from 'material-ui/Button';
  import Dialog, {
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
  } from 'material-ui/Dialog';
  import Slide from 'material-ui/transitions/Slide';
  import './modal.component.css';
  
 class EduModal extends React.Component {
    state = {
      open: false,
    };
  
    handleRequestClose = () => {
      this.setState({ open: false });
    };
  
    render() {
      return (
        <div>
          <Button color="primary" onClick={() => this.setState({ open: true })}>{this.props.children}</Button>
          <Dialog open={this.state.open} transition={Slide} onRequestClose={this.handleRequestClose}>
            <DialogTitle>{this.props.children}</DialogTitle>
            <DialogContent>
              <DialogContentText>
              the content of {this.props.children} will be displayed here in future.
              So prior to that enjoy this view and keep refreshing our page, We will be updating stuffs soon.
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              
              <Button onClick={this.handleRequestClose} className="btn-raised-color">
                {this.props.children}
              </Button>
            </DialogActions>
          </Dialog>
        </div>
      );
    }
  }

  
  class EduModalRaised extends React.Component {
    state = {
      open: false,
    };
  
    handleRequestClose = () => {
      this.setState({ open: false });
    };
  
    render() {
      return (
        <div>
          <Button className="btn-raised-color" raised onClick={() => this.setState({ open: true })}>{this.props.children}</Button>
          <Dialog open={this.state.open} transition={Slide} onRequestClose={this.handleRequestClose}>
            <DialogTitle>{this.props.children}</DialogTitle>
            <DialogContent>
              <DialogContentText>
              the content of {this.props.children} will be displayed here in future.
              So prior to that enjoy this view and keep refreshing our page, We will be updating stuffs soon.
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              
              <Button onClick={this.handleRequestClose} className="btn-raised-color">
               {this.props.children}
              </Button>
            </DialogActions>
          </Dialog>
        </div>
      );
    }
  }
  class EduModalBig extends React.Component {
    state = {
      open: false,
    };
  
    handleRequestClose = () => {
      this.setState({ open: false });
    };
  
    render() {
      return (
        <div>
          <Button className="btn-raised-color" style={{'padding-left':"40px",'padding-right':"40px",'padding-bottom':"20px",'padding-top':"20px"}} raised onClick={() => this.setState({ open: true })}>{this.props.children}</Button>
          <Dialog open={this.state.open} transition={Slide} onRequestClose={this.handleRequestClose}>
            <DialogTitle>{this.props.children}</DialogTitle>
            <DialogContent>
              <DialogContentText>
              the content of {this.props.children} will be displayed here in future.
              So prior to that enjoy this view and keep refreshing our page, We will be updating stuffs soon.
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              
              <Button onClick={this.handleRequestClose} className="btn-raised-color">
               {this.props.children}
              </Button>
            </DialogActions>
          </Dialog>
        </div>
      );
    }
  }
  export { EduModal,EduModalRaised ,EduModalBig};