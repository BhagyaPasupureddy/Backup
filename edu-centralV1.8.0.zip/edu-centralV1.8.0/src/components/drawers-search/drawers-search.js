import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Drawer from 'material-ui/Drawer';
import Button from 'material-ui/Button';
import List from 'material-ui/List';

import IntegrationAutosuggest from '../autocomplete/autocomplete.component';


const styles = {
  list: {
    width: 250,
    flex: 'initial',
    'padding':'5em',
     },
  listFull: {
    width: 'auto',
    flex: 'initial',
    'padding':'5em',
  
  },
};

class TemporaryDrawer extends React.Component {
  state = {
    open: {
      top: false,
      left: false,
      bottom: false,
      right: false,
    },
  };

  toggleDrawer = (side, open) => {
    const drawerState = {};
    drawerState[side] = open;
    this.setState({ open: drawerState });
  };

  handleTopOpen = () => {
    this.toggleDrawer('top', true);
  };

  handleTopClose = () => {
    this.toggleDrawer('top', false);
  };


  render() {
    const classes = this.props.classes;

    
  
      const fullList = (
        <div>
          <List className={classes.listFull}><IntegrationAutosuggest/></List>
          </div>
      );
    return (
      <div>
        
        <Button raised style={{background: '#512DAB',color:'white'}} onClick={this.handleTopOpen}>{this.props.children}</Button>
       
        <Drawer
          anchor="top"
          open={this.state.open.top}
          onRequestClose={this.handleTopClose}
          
        >
       {fullList}
        </Drawer>
       </div>
    );
  }
}

TemporaryDrawer.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(TemporaryDrawer);