import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import EduSplashScreen from './modules/splashscreen/splashscreen.components';
import registerServiveWorker from './registerServiceWorker';


 class Educentral extends React.Component {
    render()
    {return(
        <div>
           <EduSplashScreen />
          
            </div>
    )};
 }

ReactDOM.render(<Educentral />, document.getElementById('root'));

registerServiveWorker();
