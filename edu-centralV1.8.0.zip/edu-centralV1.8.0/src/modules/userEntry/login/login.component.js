import React from 'react';
import Button from 'material-ui/Button';
import TextField from 'material-ui/TextField';
import Dialog, {DialogContent, DialogTitle,} from 'material-ui/Dialog';
import Slide from 'material-ui/transitions/Slide';
import './login.component.css';

 class LogIn extends React.Component {

 constructor(){
   super();
       
   this._close = this._close.bind(this);
   this._open = this._open.bind(this);
   this._updateEmail = this._updateEmail.bind(this);
   this._updatePassword = this._updatePassword.bind(this);

   this.state = {
       modalOpen: false,
       username: '',
       email: '',
       password: '',

   };
}

_open() {
   this.setState({
       modalOpen: true
   });
}

_close() {
   this.setState({
       modalOpen: false
   });
}

_updateEmail(changeEvent) {
   this.setState({
       email: changeEvent.target.value
   });
}

_updatePassword(changeEvent) {
   this.setState({
       password: changeEvent.target.value
   });
}

  render() {
    return (
      <div>
        <Button className="LogIn" id="LogIn" onClick={this._open}>Log In</Button>
        <Dialog open={this.state.modalOpen} transition={Slide} onRequestClose={this._close}>
          <DialogTitle>{"Log In"}</DialogTitle>
          <DialogContent>
          <TextField id="Email"  label="Email" value={this.state.email} onChange={this._updateEmail}/><br/>
          <TextField id="Password" label="Password" type="password" value={this.state.password} onChange={this._updatePassword}/><br/>             
          </DialogContent>
          <Button className="Submit" id="LogInSubmit" raised>
          Submit
      </Button>
          
        </Dialog>
      </div>
    );
  }
}

export default LogIn;
