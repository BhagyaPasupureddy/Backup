import React from 'react';
import Button from 'material-ui/Button';
import Dialog, {DialogTitle, DialogContent} from 'material-ui/Dialog';
import {Slide} from 'material-ui/transitions/Slide';
import TextField from 'material-ui/TextField';
import './signup.css';

export default class SignUp extends React.Component {
    constructor() {
        super();
        this._close = this._close.bind(this);
        this._open = this._open.bind(this);
        this._updateUsername = this._updateUsername.bind(this);
        this._updateEmail = this._updateEmail.bind(this);
        this._updatePassword = this._updatePassword.bind(this);

        this.state = {
            modalOpen: false,
            username: '',
            email: '',
            password: '',

        };
    }

    _open() {
        this.setState({
            modalOpen: true
        });
    }

    _close() {
        this.setState({
            modalOpen: false
        });
    }

    _updateUsername(changeEvent) {
        this.setState({
            username: changeEvent.target.value
        });
    }

    _updateEmail(changeEvent) {
        this.setState({
            email: changeEvent.target.value
        });
    }

    _updatePassword(changeEvent) {
        this.setState({
            password: changeEvent.target.value
        });
    }
    
    render() {
        return (
            <div>
                <Button className="SignUp" id="SignUp" raised onClick={this._open}>
                    Sign Up
                </Button>

                <Dialog className="Dialog-Main" open={this.state.modalOpen} transition={Slide} onRequestClose={this._close}>
                    <DialogTitle>
                        <h3>Sign Up</h3>
                    </DialogTitle>
                    <DialogContent>
                        <TextField id="Username"  label="Username" value={this.state.username} onChange={this._updateUsername}/><br/>
                        <TextField id="Email"  label="Email" value={this.state.email} onChange={this._updateEmail}/><br/>
                        <TextField id="Password" label="Password" type="password" value={this.state.password} onChange={this._updatePassword}/><br/>
                    </DialogContent>
                    <Button className="Submit" id="SignUpSubmit" raised>
                        Submit
                    </Button>
                </Dialog>
               
            </div>
        );
    }
}