import React from 'react';
import './splashscreen.components.css';
import ButtonAppBar from '../../components/nav-bar/nav-bar.component';
//import { EduModalBig } from '../../components/modal/modal.component';
import pic1 from './images/1.png'; 
import pic2 from './images/2.png'; 
import pic3 from './images/3.png'; 
import pic4 from './images/4.png'; 
import TemporaryDrawer from '../../components/drawers-search/drawers-search';
//import EduModalRaised from '../../components/buttons/buttons.component';


export default class EduSplashScreen extends React.Component {
    render()
    {return(
        <div>
           <div>
               <div>
                    <ButtonAppBar />
               </div> 
               <div className="layoutcontent">
               <div className="parallax">
                    <div className="slogan">
                    <span>EduCentral</span> is designed to make your <span>Learning</span> 
                    Experience better rather than wasting your time in <span>Searching</span>.
                    </div>
                    <div className="search"> 
                       <TemporaryDrawer className="edu-raised-btn"> Click to Search </TemporaryDrawer>
                      
                  </div>
               </div>
                <div style={{height:"500px",background:'white'}}>
                    
                </div>
              </div>
                  
                
              <div style={{height:"500px",background:'white'}}>
                    
              </div>
              <div style={{'text-align': 'center','letter-spacing':'4em'}}> <img src={pic1} style={{width:"15em" }} alt="1"/>
              { ' '}<img src={pic2} style={{width:"15em"}} alt="2"/>{ ' '}
              <img style={{width:"15em"}} src={pic3} alt="3"/>{ ' '}
              <img style={{width:"15em"}} src={pic4} alt="4"/></div>
              <div style={{background:'#1e053e' ,height: '20em' }} >
              </div>
                  <div  style={{background:'#4A148C' ,height: '5px' }}></div>
                  <div style={{background:'black' ,height: '3em',color:'white',textAlign:'center'}} >
                 Copyright © EduCentral 2017
                  </div>
            </div>
            </div>
    )};
 }