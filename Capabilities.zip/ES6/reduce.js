const animals = [
    {
        "name": "cat",
        "size": "small",
        "weight": 5
    },
    {
        "name": "dog",
        "size": "small",
        "weight": 10
    },
    {
        "name": "lion",
        "size": "medium",
        "weight": 150
    },
    {
        "name": "elephant",
        "size": "big",
        "weight": 5000
    }
]
let total_weight = 0;

for (let i = 0; i < animals.length; i++) {
    total_weight += animals[i].weight
}
let total_weight1 = animals.reduce((weight, animal, index, animals) => {
    return weight += animal.weight
}, 0)

console.log(total_weight);
console.log(total_weight1);