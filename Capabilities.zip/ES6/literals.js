"use strict";

let name = 'Bhagi';

console.log('My favouite person is '+name+' because....');
console.log(`My favouite person is ${name}`);

let a=3;
let b=8;

console.log(`Sum: ${a+b} `);
