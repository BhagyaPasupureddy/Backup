"use strict";

function addNumber(a,b,c,d) 
{
    console.log(a+b+c+d);

}

var nums=[3,4,7,7];
//addNumber(nums[0],nums[1],nums[2]);
 
 addNumber(...nums);

 var meats=['chicken','fish'];
 var food=['choco',...meats,'apples','mango'];

 console.log(food);
