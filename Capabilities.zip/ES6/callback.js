"use strict";

let add = (a,b) => (a+b);

function myfunc(a,b,c){

    console.log(c(a,b));

}

myfunc(10,80,add);
