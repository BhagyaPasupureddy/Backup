"use strict";

 class Person{

     constructor(name,age,weight){
         this.name=name;
         this.age=age;
         this.weight=weight;
     }
     displayweight(){
         console.log(this.weight);
     }
 }
 let bhagi=new Person('Bhagi',21,52);
 bhagi.displayweight();