let sum=0;
let str="";
let func = (...args) => {

    for (i of args) {

        if (Number.isInteger(i) === true) {
             sum = sum+i;
            console.log(sum);
        }

        else {
            str=str.concat(i + " ");
            console.log(str);
        }
    }
    console.log(sum);
    console.log(str);

}
func("Bhagi", 989, 5,"is",9,67,"a","good",3421,"girl");