"use strict";

let movie="Hello";
function theNoteBook()
{
let movie='the notebook';
return movie;
}
console.log(movie);
console.log(theNoteBook());
console.log(movie);

function buckyFunction()
{
    let isHorse=true;
    let saying="Bacon is good";
    console.log('\nBefore if:',saying);

    if(isHorse){
        let saying='I am a horse';
        console.log('Inside if:',saying);
    }
        console.log('\nAfter if:',saying);

}
buckyFunction();
