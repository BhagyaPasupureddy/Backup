"use strict";

 class Person{

     constructor(name,age,weight){
         this.name=name;
         this.age=age;
         this.weight=weight;
     }
       displayName(){
         console.log(this.name);
       }
         displayAge(){
         console.log(this.age);
     }
     displayWeight(){
         console.log(this.weight);
     }
 }

 class Programmer extends Person{
    constructor(name,age,weight,language){
        super(name,age,weight);
        this.language=language;

     }
    displayLanguage()
    {
        console.log(this.language);

    }
 }
 
let bhagi=new Person('Bhagi',21,52);
bhagi.displayWeight();
bhagi.displayAge();
bhagi.displayName();

console.log('--------');

let lucky=new Programmer('Lucky',25,75,'Java');
lucky.displayName();
lucky.displayAge();
lucky.displayWeight();
lucky.displayLanguage();
