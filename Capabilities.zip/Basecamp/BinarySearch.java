package com.mindtree.c1;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		int arr[]={6,9,23,33};
		System.out.println("Enter any element");
		int x=sc.nextInt();
		int r=search(arr,x);
		  if(r==-1)
		    System.out.println("Element not found");
		  else
			  System.out.println("Element found at index "+r);
		
	}

  static int search(int[] arr, int x) {
		// TODO Auto-generated method stub
	    int l=0;
		int h=arr.length-1;
		while(l<=h)
		  {
		       int m=l+(h-1)/2;
			if(arr[m]==x)
		           return m;
		          if(arr[m]<x)
		        	  l=m+1;
		          else
		        	  h=m-1;
		       
		  }
		return -1;
	}
	
}
