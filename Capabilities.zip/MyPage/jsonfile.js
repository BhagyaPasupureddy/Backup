function makejson(form)
{
    var myJson,text,obj;
    console.log("Hello");
    var json={

        "book_title":"MY LIFE MY WISH",
        "author_name":"Bhagi"
    };

    var json = { "book_title": form.book_title.value,
    "author_name": form.author_name.value};


    console.log(json);
    myJson=JSON.stringify(json);
    return false;
    
}