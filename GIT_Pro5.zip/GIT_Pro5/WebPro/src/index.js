import './styles.scss';
var msg = x=> { 
    console.log(x) 
 } 
 msg(10)
 